package com.to;

public class BalanceTO {
	private String name;
	private int accnumb;
	public final String getName() {
		return name;
	}
	public final void setName(String name) {
		this.name = name;
	}
	public final int getAccnumb() {
		return accnumb;
	}
	public final void setAccnumb(int accnumb) {
		this.accnumb = accnumb;
	}
	
}
