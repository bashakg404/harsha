package com.to;

public class WithdrawTO {
	private int withdrawamount;
	private String name;
	private int accnumber;
	public final int getWithdrawamount() {
		return withdrawamount;
	}
	public final void setWithdrawamount(int withdrawamount) {
		this.withdrawamount = withdrawamount;
	}
	public final String getName() {
		return name;
	}
	public final void setName(String name) {
		this.name = name;
	}
	public final int getAccnumber() {
		return accnumber;
	}
	public final void setAccnumber(int accnumber) {
		this.accnumber = accnumber;
	}
	
}
